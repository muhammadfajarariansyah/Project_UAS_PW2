import React from 'react';
import { Plus, Edit2, Trash2 } from 'lucide-react';

const API_BASE_URL = 'http://localhost:8000/api';

const Participants = ({ participants, openModal, fetchParticipants }) => {
    const deleteParticipant = async (id) => {
        if (!confirm('Yakin ingin menghapus peserta ini?')) return;
        
        try {
        await fetch(`${API_BASE_URL}/participants/${id}`, { method: 'DELETE' });
        fetchParticipants();
        } catch (error) {
        console.error('Error deleting participant:', error);
        }
    };

    return (
        <div className="table-container">
        <div className="table-header">
            <h3 className="table-title">Data Peserta</h3>
            <button onClick={() => openModal('peserta')} className="btn-add">
            <Plus className="w-4 h-4" />
            Tambah Peserta
            </button>
        </div>
        
        <table className="data-table">
            <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Jenis Kelamin</th>
                <th>Umur</th>
                <th>Kelas</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            {participants.map((p, index) => (
                <tr key={p.id}>
                <td>{index + 1}</td>
                <td>{p.nama}</td>
                <td>{p.email}</td>
                <td>{p.jenis_kelamin}</td>
                <td>{p.umur}</td>
                <td>{p.kelas?.nama_kelas}</td>
                <td>
                    <span className={`status-badge ${p.status === 'Aktif' ? 'active' : 'inactive'}`}>
                    {p.status}
                    </span>
                </td>
                <td>
                    <div className="action-buttons">
                    <button onClick={() => openModal('peserta', p)} className="btn-icon edit">
                        <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => deleteParticipant(p.id)} className="btn-icon delete">
                        <Trash2 className="w-4 h-4" />
                    </button>
                    </div>
                </td>
                </tr>
            ))}
            </tbody>
        </table>
        </div>
    );
};

export default Participants;