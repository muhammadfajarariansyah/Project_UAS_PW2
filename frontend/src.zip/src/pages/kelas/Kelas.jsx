import React from 'react';
import { Plus, Edit2, Trash2, Users, GraduationCap } from 'lucide-react';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api';
const Kelas = ({ kelas, openModal, fetchKelas, onSelectKelas }) => {



  const deleteKelas = async (e, id) => {
    e.stopPropagation();
    if (!confirm('Yakin ingin menghapus kelas ini?')) return;
    try {
      await fetch(`${API_BASE_URL}/kelas/${id}`, { method: 'DELETE' });
      fetchKelas();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="container">
      <div className="table-header">
        <h3 className="table-title">Daftar Kelas</h3>
        <button onClick={() => openModal('kelas')} className="btn-add">
          <Plus className="w-4 h-4" /> Tambah Kelas
        </button>
      </div>

      <div className="kelas-grid">
        {kelas.map((k) => (
          <div key={k.id} className="kelas-card" onClick={() => onSelectKelas(k)}>
            <div>
              <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '1rem'}}>
                <span className={`status-badge ${k.status === 'Aktif' ? 'active' : 'inactive'}`}>
                  {k.status}
                </span>
                <span className="stat-card-title">{k.level}</span>
              </div>
              <h2 style={{fontSize: '1.25rem', fontWeight: '700', marginBottom: '0.5rem'}}>{k.nama_kelas}</h2>
              <p style={{color: '#64748b', fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '5px'}}>
                <GraduationCap size={16}/> {k.nama_pengajar}
              </p>
            </div>

            <div style={{marginTop: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
              <div style={{display: 'flex', alignItems: 'center', gap: '5px', color: '#2563eb', fontWeight: '600'}}>
                <Users size={18}/> {k.participants_count || 0} Peserta
              </div>
              <div className="action-buttons" onClick={(e) => e.stopPropagation()}>
                <button onClick={() => openModal('kelas', k)} className="btn-icon edit">
                  <Edit2 className="w-4 h-4" />
                </button>
                {/* Tambahkan fungsi delete di sini */}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Kelas;