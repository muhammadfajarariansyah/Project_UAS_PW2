import React from 'react';
import { Search, Users, LogOut, Menu, X } from 'lucide-react';

const Layout = ({ children, sidebarOpen, setSidebarOpen, activePage, setActivePage, searchQuery, setSearchQuery }) => {
    return (
        <div className="app-container">
        {/* Sidebar */}
        <div className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
            <div className="sidebar-header">
            <div className="sidebar-logo">
                <span>🇬🇧</span>
            </div>
            <div className="sidebar-brand">
                <h1>English</h1>
                <p>Academy</p>
            </div>
            </div>

            <div className="sidebar-content">
            <div className="sidebar-user">
                <div className="sidebar-user-avatar">
                <Users className="w-6 h-6 text-purple-600" />
                </div>
                <div className="sidebar-user-info">
                <p>Admin</p>
                <p>adm1107@gmail.com</p>
                </div>
            </div>

            <nav className="sidebar-nav">
                <button
                onClick={() => setActivePage('dashboard')}
                className={`sidebar-nav-item ${activePage === 'dashboard' ? 'active' : ''}`}
                >
                Beranda
                </button>
                <button
                onClick={() => setActivePage('kelas')}
                className={`sidebar-nav-item ${activePage === 'kelas' ? 'active' : ''}`}
                >
                Data Kelas
                </button>
                <button
                onClick={() => setActivePage('peserta')}
                className={`sidebar-nav-item ${activePage === 'peserta' ? 'active' : ''}`}
                >
                Data Peserta
                </button>
            </nav>

            <button className="sidebar-logout">
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
            </button>
            </div>
        </div>

        {/* Main Content */}
        <div className="main-content">
            {/* Header */}
            <header className="header">
            <div className="header-left">
                <button onClick={() => setSidebarOpen(!sidebarOpen)} className="header-toggle">
                {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>
                <h2 className="header-title">Beranda</h2>
            </div>
            <div className="header-search">
                <div className="search-wrapper">
                <Search className="search-icon w-5 h-5" />
                <input
                    type="text"
                    placeholder="Cari Kelas atau Peserta"
                    className="search-input"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                </div>
            </div>
            </header>

            {/* Content Area */}
            <main className="content-area">
            {children}
            </main>
        </div>
        </div>
    );
};

export default Layout;